# Sign detection > 2023-08-21 10:10pm
https://universe.roboflow.com/university-of-south-asia/sign-detection-ci6ms

Provided by a Roboflow user
License: CC BY 4.0

